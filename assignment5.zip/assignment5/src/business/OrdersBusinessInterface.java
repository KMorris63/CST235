package business;

/*
 * Kacey Morris
 * November 20, 2020
 * CST 235 Databases
 * 
 * This interface outlines what an orders business service requires.
 * 
 * This is my own work, as influenced by class time and examples.
 */

import java.util.List;

import javax.ejb.Local;

import beans.Order;

@Local
public interface OrdersBusinessInterface {
	// required methods
	public void test();
	public List<Order> getOrders();
	public void setOrders(List<Order> orders);
}