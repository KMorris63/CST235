package beans;

/*
 * Kacey Morris
 * November 20, 2020
 * CST 235 Databases
 * 
 * This class outlines a single order and the properties and methods connected to that object type.
 * 
 * This is my own work, as influenced by class time and examples.
 */

public class Order {
	// properties
	String orderNum;
	String productName;
	float price;
	int quantity;
	
	// default constructor
	public Order() {
		orderNum = "";
		productName = "";
		price = 0;
		quantity = 0;
	}
	
	// data constructor
	public Order(String oNum, String pName, float passPrice, int quant) {
		orderNum = oNum;
		productName = pName;
		price = passPrice;
		quantity = quant;
	}
	
	// getters and setters
	public String getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}	
}