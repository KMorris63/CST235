package business;

/*
 * Kacey Morris
 * December 9, 2020
 * CST 235 REST Services and Messages
 * 
 * This is the interface for all business services.
 * 
 * This is my own work as influenced by class time and examples.
 */

import java.util.List;

import javax.ejb.Local;

import beans.Verse;

@Local
public interface VerseBusinessInterface {
	// required methods
	public List<Verse> getAllVerses();
	public List<Verse> getSingleVerse(int b, int c, int v);
}
