package business;

/*
 * Kacey Morris
 * December 9, 2020
 * CST 235 REST Services and Messages
 * 
 * This is the main orders business service.
 * 
 * This is my own work as influenced by class time and examples.
 */

import java.io.Serializable;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Verse;
import database.VerseDataService;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Stateless
@Local(VerseBusinessInterface.class)
@Alternative
@LocalBean
public class VerseBusinessService implements VerseBusinessInterface {

    /**
     * Default constructor. 
     */
    public VerseBusinessService() {

    }

	@Override
	public List<Verse> getAllVerses() {
		VerseDataService vds = new VerseDataService();
		return vds.getAllVerses();
	}

	@Override
	public List<Verse> getSingleVerse(int b, int c, int v) {
		VerseDataService vds = new VerseDataService();
		return vds.getSingleVerse(b, c, v);
	}
}
