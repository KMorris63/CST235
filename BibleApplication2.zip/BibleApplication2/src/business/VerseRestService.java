package business;

/*
 * Kacey Morris
 * December 9, 2020
 * CST 235 REST Services and Messages
 * 
 * The rest service allows for the database information to be seen in json and xml format.
 * 
 * This is my own work as influenced by class time and examples.
 */

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import beans.Verse;
import database.VerseDataService;

// annotations
@RequestScoped
@Path("/verses")
@Produces({ "application/json" })
@Consumes({ "application/json" })
public class VerseRestService {
	// use the data service
	@Inject
	VerseBusinessInterface vbi;
	
	// get all records and display them in json format
	@GET
	@Path("/getjson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Verse> getVersesAsJson() {
		return vbi.getAllVerses();
	}
	
	// get a single record by parameters and display
	@GET
	@Path("/getsinglejson")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Verse> getSingleVerseAsJson(
			@DefaultValue("1") @QueryParam("book")int book, 
			@DefaultValue("1") @QueryParam("chapter")int chapter, 
			@DefaultValue("1") @QueryParam("verseNum")int verseNum
			) {
		return vbi.getSingleVerse(book, chapter, verseNum);
	}
	// http://localhost:8080/assignment6/rest/verses/getsinglejson?book=1&chapter=1&verse=1
}
