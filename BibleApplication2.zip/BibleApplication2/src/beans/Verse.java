package beans;

/*
 * Kacey Morris
 * December 9, 2020
 * CST 235 REST Services and Messages
 * 
 * This outlines an order object.
 * 
 * This is my own work as influenced by class time and examples.
 */

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.xml.bind.annotation.XmlRootElement;

@ManagedBean
@XmlRootElement(name="Verse")
public class Verse implements Serializable {
	// properties
	int ID;
	int bookNum;
	int chapterNum;
	int verseNum;
	String verseText;
		
	// default constructor
	public Verse() {
		ID = 1001001;
		bookNum = 1;
		chapterNum = 1;
		verseNum = 1;
		verseText = "In the beginning God created the heaven and the earth.";
	}
		
	// data constructor
	public Verse(int pID, int pBook, int pChap, int pVerse, String pText) {
		ID = pID;
		bookNum = pBook;
		chapterNum = pChap;
		verseNum = pVerse;
		verseText = pText;
	}

	public int getBookNum() {
		return bookNum;
	}

	public void setBookNum(int bookNum) {
		this.bookNum = bookNum;
	}

	public int getChapterNum() {
		return chapterNum;
	}

	public void setChapterNum(int chapterNum) {
		this.chapterNum = chapterNum;
	}

	public int getVerseNum() {
		return verseNum;
	}

	public void setVerseNum(int verseNum) {
		this.verseNum = verseNum;
	}

	public String getVerseText() {
		return verseText;
	}

	public void setVerseText(String verseText) {
		this.verseText = verseText;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
}
